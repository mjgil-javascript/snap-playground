0.0.2 - December 19, 2013
-------------------------
* add repository to package.json

0.0.1 - December 18, 2013
-------------------------
:sparkles: