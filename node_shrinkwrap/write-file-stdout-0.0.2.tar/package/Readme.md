# write-file-stdout

  Write to a file, falling back to stdout.

## Installation

    $ npm install write-file-stdout

## API

### write ([file], contents)

  Write `contents` to a `file`, falling back to stdout.

## License

  MIT
