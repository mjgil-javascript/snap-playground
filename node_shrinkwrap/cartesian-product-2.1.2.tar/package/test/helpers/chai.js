
'use strict';

var chai = require('chai');

global.expect = chai.expect;
