# postcss-quantity-queries changelog

## 0.4.0
(2015-09-04)

* Upgrade to PostCSS 5
([81515c1](https://github.com/pascalduez/postcss-quantity-queries/commit/81515c1b4bd79428e9283e5ff8c3a07c449ef15a))


## 0.3.1
(2015-05-02)

* Use standard package keyword
([#319](https://github.com/postcss/postcss/issues/319))

## 0.3.0
(2015-04-08)

* Use latest PostCSS 4.1.* plugin API ([16b7a8a](https://github.com/pascalduez/postcss-map/commit/16b7a8ac8aad17e400821d5f6454b86223abe487))
* Upgrade to Babel 5.0 ([4754352](https://github.com/pascalduez/postcss-map/commit/475435295f30727e3e91330b8b0a850d20812eae))

## 0.2.0
(2015-03-12)

* Added a new pseudo-selectors API.
([#2](https://github.com/pascalduez/postcss-quantity-queries/issues/2))

## 0.1.0
(2015-03-09)

* Initial release.
