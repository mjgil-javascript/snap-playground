# 2.1.1

* Remove unused runtime dependency to minimatch
* Update postcss in test to >=3.0.5

## 2.1.0

* Add first-letter and first-line to the default value of the selectors option

## 2.0.0

* Output the single colon selectors only, since rules containing double colon selectors are ignored by IE 8

## 1.0.0

* Initial version
