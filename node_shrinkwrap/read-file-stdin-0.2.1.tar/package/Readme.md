
# read-file-stdin

  Read from a file, falling back to stdin.

## Installation

    $ npm install read-file-stdin

## API

### read ([file], callback)

  Read from a `file`, falling back to stdin, and `callback(err, buffer)`.

## License

  MIT