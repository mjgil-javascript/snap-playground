
0.2.1 - January 21, 2016
------------------------
* add tests to `.npmignore`

0.2.0 - October 15, 2014
-------------------------
* returning a single buffer rather than an array (better for large inputs)

0.0.4 - May 7, 2014
-------------------------
* switch from `node-concat-stream` to `stream-to-array`

0.0.3 - December 19, 2013
-------------------------
* add repository to package.json

0.0.2 - December 19, 2013
-------------------------
* peg node-concat-stream

0.0.1 - December 18, 2013
-------------------------
:sparkles:
