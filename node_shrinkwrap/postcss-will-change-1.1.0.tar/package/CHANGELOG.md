## 1.1
* Do not add `backface-visibility` if rule already has it (by Joe Lencioni).

## 1.0
* Use PostCSS 5.0 API.

## 0.2
* Support PostCSS 4.1 API.

## 0.1
* Initial release.
