1.3.0 / 2013-11-02
------------------

- API change: now lib takes Array/Uint8Array as TTF data,
  and return ByteBuffer object. ByteBuffer.buffer contains
  Array/Uint8Array with EOT file.
- Removed `Buffer` dependency, should work in browser too.


1.2.0 / 2013-04-21
------------------

- Separated CLI to make script useable as library (node.js package)


0.1.1 / 2013-04-05
------------------

- Fixed compatibility with original CLI params format

0.1.0 / 2013-04-04
------------------

- First release.

