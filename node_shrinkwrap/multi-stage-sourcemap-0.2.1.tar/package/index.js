/**
 * Created by azu on 2014/07/02.
 * LICENSE : MIT
 */
"use strict";
module.exports = {
    transfer: require("./lib/multi-stage-sourcemap")
};