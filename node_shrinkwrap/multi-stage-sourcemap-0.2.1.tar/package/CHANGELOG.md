## 0.2.0 (2014-08-26)


## 0.1.0 (2014-07-02)


#### Bug Fixes

* **exp:** fix file path ([74257d46](https://github.com/azu/multi-stage-sourcemap/commit/74257d46cc524ff382c7ddb464084661b9986349))


