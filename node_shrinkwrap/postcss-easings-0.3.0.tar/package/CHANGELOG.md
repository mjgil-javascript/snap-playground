## 0.3
* Use PostCSS 5.0.
* Fix error reports.

## 0.2
* Support PostCSS 4.1 API.

## 0.1
* Initial release.
