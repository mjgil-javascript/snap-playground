module.exports = function(source) {
	return JSON.stringify(this);
};
