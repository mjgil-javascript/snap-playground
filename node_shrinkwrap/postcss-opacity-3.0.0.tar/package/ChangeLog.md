3.0.0 - 2015-09-14

* Upgrade to PostCSS 5

2.0.1 - 2015-08-12

* Upgrade to PostCSS 4.1.x

2.0.0 - 2015-03-23

* Generate fallback for IE8 only

1.0.0 - 2015-02-19

* Initial release